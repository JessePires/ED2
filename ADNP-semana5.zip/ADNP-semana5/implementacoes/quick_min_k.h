#pragma once

int quick_min_k (int *v, int left, int right, int k);
