#pragma once

int heap_min_k (int *v, int n, int k);
