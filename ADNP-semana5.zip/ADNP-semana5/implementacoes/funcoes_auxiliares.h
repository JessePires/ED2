#pragma once

int min (int *v, int inicio, int fim);
int max (int *v, int inicio, int fim);
void troca (int *v, int i, int j);
void print_vector (int *v, int n);
