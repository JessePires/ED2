#pragma once

int selection_min_k (int *v, int n, int k);
