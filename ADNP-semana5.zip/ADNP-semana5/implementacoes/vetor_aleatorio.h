#pragma once

int* random_vector_unique_elems(int n, int seed);
